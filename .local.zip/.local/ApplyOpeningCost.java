import java.sql.*;
import java.nio.file.*;
public class ApplyOpeningCost {
 public static void main(String[] args)throws Exception{
 try(var c=DriverManager.getConnection(System.getenv("SPRING_DATASOURCE_URL"),System.getenv("SPRING_DATASOURCE_USERNAME"),System.getenv("SPRING_DATASOURCE_PASSWORD"));var s=c.createStatement()){
 try(var r=s.executeQuery("SELECT COUNT(*) FROM SHOP_MIGRATION WHERE VERSION='V007'")){r.next();if(r.getInt(1)>0){System.out.println("V007 already applied");return;}}
 String sql=Files.readString(Path.of("backend_java/src/main/resources/db/migrations/V007__opening_stock_cost.sql"));
 for(String statement:sql.split(";")){statement=statement.trim();if(statement.isEmpty()||statement.equals("COMMIT"))continue;if(statement.startsWith("CREATE TABLE")){try(var r=s.executeQuery("SELECT COUNT(*) FROM USER_TABLES WHERE TABLE_NAME='INVENTORY_COST_OPENING'")){r.next();if(r.getInt(1)>0)continue;}}s.execute(statement);}
 System.out.println("V007 applied; no existing prices or quantities changed");
 }
 }
}