const fs=require('fs'),acorn=require('./refactor-tools/node_modules/acorn');
const root='backend_java/src/main/resources/static/',p=root+'admin/js/core/router.js',s=fs.readFileSync(p,'utf8'),ast=acorn.parse(s,{ecmaVersion:'latest'}),edits=[],pages={};
const load=ast.body.find(n=>n.id.name==='load'),chain=load.body.body.find(n=>n.type==='TryStatement').block.body.find(n=>n.type==='IfStatement');
let n=chain;
while(n){const cond=s.slice(n.test.start,n.test.end),m=cond.match(/^section==='(\w+)'$/);if(m){(pages[m[1]]??={}).render=s.slice(n.consequent.start+1,n.consequent.end-1);}else if(cond.includes("section==='history'")){pages.history={render:s.slice(n.consequent.start+1,n.consequent.end-1)};pages.audit=pages.history;}n=n.alternate;}
edits.push([chain.start,chain.end,`if(window.AdminV8?.[section]?.render)html=await window.AdminV8[section].render();
 else if(window.AdminModules?.[section]?.render)html=await window.AdminModules[section].render();
 else if(window.AdminPages?.[section]?.render)html=await window.AdminPages[section].render();`]);
const action=ast.body.find(n=>n.id.name==='action'),actions=action.body.body.find(n=>n.type==='IfStatement'&&s.slice(n.test.start,n.test.end)==="section==='categories'");
n=actions;while(n){const cond=s.slice(n.test.start,n.test.end),m=cond.match(/^section==='(\w+)'$/);if(m)(pages[m[1]]??={}).action=s.slice(n.consequent.start+1,n.consequent.end-1);n=n.alternate;}
edits.push([actions.start,actions.end,'if(window.AdminPages?.[section]?.action)return window.AdminPages[section].action(a,id);']);
let out=s;for(const [start,end,replacement]of edits.sort((a,b)=>b[0]-a[0]))out=out.slice(0,start)+replacement+out.slice(end);fs.writeFileSync(p,out);
const files=[];for(const [name,parts]of Object.entries(pages)){const dest=`admin/js/pages/${name}/editor-list.js`;fs.mkdirSync(root+`admin/js/pages/${name}`,{recursive:true});fs.writeFileSync(root+dest,`'use strict';\nwindow.AdminPages??={};\nwindow.AdminPages.${name}={\n${parts.render?`async render(){let html='';${parts.render}\nreturn html;},`:''}\n${parts.action?`async action(a,id){${parts.action}},`:''}\n};\n`);files.push(dest);}
const mp=root+'admin/js/manifest.json',manifest=JSON.parse(fs.readFileSync(mp));manifest['admin.js'].splice(-2,0,...files);fs.writeFileSync(mp,JSON.stringify(manifest,null,2)+'\n');
const hp=root+'admin/index.html';fs.writeFileSync(hp,fs.readFileSync(hp,'utf8').replace('<script defer src="/admin/js/core/router.js">',files.map(p=>`<script defer src="/${p}"></script>`).join('')+'<script defer src="/admin/js/core/router.js">'));
