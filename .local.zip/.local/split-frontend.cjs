const fs=require('fs'),path=require('path'),acorn=require('./refactor-tools/node_modules/acorn');
const root='backend_java/src/main/resources/static/',old=root+'admin-assets/';
const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s)};
const manifest={};
function splitTop(file,choose){const src=fs.readFileSync(old+file,'utf8'),ast=acorn.parse(src,{ecmaVersion:'latest'}),groups=new Map();
 for(const node of ast.body){const name=node.id?.name||node.declarations?.[0]?.id?.name||'';const dest=choose(name,node);if(!groups.has(dest))groups.set(dest,[]);groups.get(dest).push(src.slice(node.start,node.end));}
 manifest[file]=[...groups.keys()];for(const [p,parts]of groups)write(root+p,parts.join('\n\n')+'\n');
}
splitTop('admin.js',(n,node)=>{
 if(['$','esc','titles','statusNames','csrf','money','date','active','statusOptions','movementName'].includes(n)||node.type==='ExpressionStatement'&&node.expression.type==='Literal')return 'admin/js/core/state.js';
 if(n==='api')return 'admin/js/core/api.js';
 if(['productCodeInput','variantSkuInput','refreshVariantSku','namedLookup','productPhotoFields','bindProductPhotos'].includes(n))return 'admin/js/pages/products/form.js';
 if(['categoryChoices','categorySearch','bindCategorySearch'].includes(n))return 'admin/js/pages/categories/picker.js';
 if(n==='imageEditor')return 'admin/js/pages/products/images.js';
 if(['orderReturnPanel','orderInventoryPanel','orderEditor'].includes(n))return 'admin/js/pages/orders/detail.js';
 if(['load','action'].includes(n))return 'admin/js/core/router.js';
 if(node.type==='FunctionDeclaration')return 'admin/js/core/ui.js';
 return 'admin/js/app.js';
});
function splitFactory(file,namespace,helpers,group){const src=fs.readFileSync(old+file,'utf8'),ast=acorn.parse(src,{ecmaVersion:'latest'});const assignment=ast.body.find(n=>n.type==='ExpressionStatement'&&n.expression.type==='AssignmentExpression').expression;const body=assignment.right.callee.body.body;const groups=new Map();
 for(const node of body){if(node.type==='ReturnStatement')continue;const name=node.id?.name||node.declarations?.[0]?.id?.name||'';const key=helpers.includes(name)?'helpers':group(name);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(src.slice(node.start,node.end));}
 const files=[];for(const [key,parts]of groups){const p=key==='helpers'?`admin/js/core/${file.replace('.js','')}-helpers.js`:`admin/js/pages/${key}.js`;files.push(p);const exports=key==='helpers'?helpers:[];let tail='';
 if(key==='helpers')tail=`window.${namespace}Utils={${exports.join(',')}};`;
 else if(file==='workflow.js'){const names={ 'inventory/stock':['skuCost','stock'],'inventory/history':['history'],'audit/index':['audit'],'categories/index':['categories'],'vouchers/index':['vouchers'],'dashboard/index':['dashboard'],'orders/refunds':['refundPanel','refundForm'],'reports/inventory':['inventoryReport'],'shipping/index':['shipping']}[key]||[];tail=names.map(n=>`window.${namespace}.${n}=${n};`).join('\n');}
 else {const exportsMap={'reports/revenue':'reports:{render:renderReports,action:reportAction}','inventory/documents':'documents:{render:renderDocuments,action:documentAction,detail:detailDocument,create:createDocument}','reports/legacy-inventory':'inventoryReport:{render:renderInventoryReport}'};tail=`Object.assign(window.${namespace},{${exportsMap[key]||''}});`;}
 write(root+p,`'use strict';\n${key==='helpers'?`window.${namespace}={};`:''}\n(()=>{\n${key==='helpers'?'':`const {${helpers.join(',')}}=window.${namespace}Utils;`}\n${parts.join('\n\n')}\n${tail}\n})();\n`);
 }
 manifest[file]=files;
}
splitFactory('workflow.js','AdminV8',['params','known','isAdmin','kind','labels','dates','allRows','csv','valuation'],n=>({skuCost:'inventory/stock',stock:'inventory/stock',history:'inventory/history',auditNames:'audit/index',audit:'audit/index',categories:'categories/index',effective:'vouchers/index',vouchers:'vouchers/index',dashboard:'dashboard/index',refundPanel:'orders/refunds',refundForm:'orders/refunds',inventoryReport:'reports/inventory',shipping:'shipping/index'}[n]||'shared/workflow'));
// The public helpers are used by the main router and document pages.
fs.appendFileSync(root+manifest['workflow.js'][0],'Object.assign(window.AdminV8,window.AdminV8Utils);\n');
splitFactory('operations.js','AdminModules',['types','states','admin','choose','today','year','query'],n=>/Document|document|orderIssue/.test(n)?'inventory/documents':n==='renderInventoryReport'?'reports/legacy-inventory':'reports/revenue');
const moves={'admin.css':'admin/css/admin.css','password-visibility.js':'shared/js/password-visibility.js','login.js':'auth/js/login.js','recovery.js':'auth/js/recovery.js','store.js':'store/js/store.js'};
for(const [name,dest]of Object.entries(moves)){if(fs.existsSync(old+name)){write(root+dest,fs.readFileSync(old+name));manifest[name]=[dest];}}
// Maintain declaration order: scripts execute after the DOM is parsed, app boots last.
manifest['admin.js'].sort((a,b)=>{const rank=p=>p.endsWith('/state.js')?0:p.endsWith('/api.js')?1:p.endsWith('/ui.js')?2:p.endsWith('/router.js')?4:p.endsWith('/app.js')?5:3;return rank(a)-rank(b)});
write(root+'admin/js/manifest.json',JSON.stringify(manifest,null,2)+'\n');
function walk(dir){return fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(dir,e.name)):[path.join(dir,e.name)])}
for(const file of [...walk(root),...walk('giao dien')].filter(p=>/\.(html|js)$/.test(p)&&!p.includes('admin-assets'))){let s=fs.readFileSync(file,'utf8');s=s.replace(/<script defer src="\/admin-assets\/(operations|workflow|admin)\.js"><\/script>/g,(_,name)=>manifest[name+'.js'].map(p=>`<script defer src="/${p}"></script>`).join(''));for(const [name,paths]of Object.entries(manifest)){if(paths.length===1)s=s.replaceAll('/admin-assets/'+name,'/'+paths[0]);}write(file,s);}
// Fixtures read the same source manifest as the delivered page, keeping existing isolated suites.
write('tools/helpers/frontend-assets.cjs',`const fs=require('fs'),path=require('path');\nconst root=path.resolve(__dirname,'../../backend_java/src/main/resources/static');\nconst manifest=require(path.join(root,'admin/js/manifest.json'));\nexports.readAsset=name=>(manifest[name]||[name]).map(p=>fs.readFileSync(path.join(root,p),'utf8')).join('\\n');\n`);
for(const file of ['tools/frontend.test.cjs','tools/workflow.test.cjs','tools/shipping.test.cjs']){let s=fs.readFileSync(file,'utf8');s="const {readAsset}=require('./helpers/frontend-assets.cjs');\n"+s;s=s.replace(/fs\.readFileSync\(path\.join\((?:staticRoot|root),'admin-assets\/([^']+)'\),'utf8'\)/g,(_,n)=>`readAsset('${n}')`).replace(/fs\.readFileSync\(path\.join\((?:staticRoot|root),'admin-assets',file\),'utf8'\)/g,'readAsset(file)').replace(/fs\.readFileSync\(path\.join\(__dirname,'\.\.\/backend_java\/src\/main\/resources\/static\/admin-assets\/store.js'\),'utf8'\)/g,"readAsset('store.js')");write(file,s);}
// Remove only the explicitly migrated source files; preserve any unknown assets.
for(const n of Object.keys(manifest))fs.unlinkSync(old+n);
