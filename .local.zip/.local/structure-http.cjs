const fs=require('fs');
(async()=>{
 const root='backend_java/src/main/resources/static/';
 const html=fs.readFileSync(root+'admin/index.html','utf8');
 const paths=[...html.matchAll(/(?:src|href)="(\/(?:admin|shared)\/[^"\s]+\.(?:js|css))"/g)].map(m=>m[1]);
 const all=['/login','/forgot-password','/shop/index.html','/store/index.html','/auth/js/login.js','/auth/js/recovery.js','/store/js/store.js','/store/css/store.css',...paths];
 for(const p of all){const r=await fetch('http://localhost:8080'+p,{redirect:'manual'});if(r.status!==200)throw Error(p+' '+r.status);}
 console.log('HTTP OK: '+all.length+' pages/assets');
 const r=await fetch('http://localhost:8080/api/products');console.log('Catalog API: '+r.status);if(r.status!==200)process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
