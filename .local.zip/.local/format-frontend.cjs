const fs=require('fs'),path=require('path'),prettier=require('./refactor-tools/node_modules/prettier');
const root='backend_java/src/main/resources/static/';
const walk=p=>fs.readdirSync(p,{withFileTypes:true}).flatMap(e=>e.isDirectory()?walk(path.join(p,e.name)):[path.join(p,e.name)]);
(async()=>{for(const p of walk(root).filter(p=>/\.(js|html|css)$/.test(p)&&!p.includes(path.sep+'store'+path.sep+'assets'+path.sep))){let s=fs.readFileSync(p,'utf8').replaceAll('/admin-assets/store.css','/store/css/store.css');fs.writeFileSync(p,await prettier.format(s,{filepath:p,tabWidth:2,printWidth:100}));}})().catch(e=>{console.error(e);process.exitCode=1});
