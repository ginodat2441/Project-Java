const fs=require('fs'),base='backend_java/src/main/java/com/example/clothingshop/';
const edit=(p,fn)=>fs.writeFileSync(base+p,fn(fs.readFileSync(base+p,'utf8')));
edit('service/admin/AdminService.java',s=>s.replace('db.one("SELECT ID FROM "+kind+" WHERE ID=:i AND DELETE_FLAG=0","i",id)','queries.lookupById(kind,id)').replace('db.update("LOCK TABLE "+kind+" IN EXCLUSIVE MODE")','queries.lockLookup(kind)').replace('db.rows("SELECT ID FROM "+kind+" WHERE LOWER(TRIM("+column+"))=LOWER(:n) AND DELETE_FLAG=0 ORDER BY ID","n",normalized)','queries.lookupByName(kind,column,normalized)').replace('db.insert("INSERT INTO "+kind+"("+column+") VALUES(:n)","n",normalized)','queries.insertLookup(kind,column,normalized)'));
edit('repository/admin/AdminOperationsRepository.java',s=>s.trim().slice(0,-1)+`
 private static void validateLookup(String kind,String column){
  if(!Map.of("BRAND","BRAND_NAME","MATERIAL","MATERIAL_NAME").getOrDefault(kind,"").equals(column))throw new IllegalArgumentException("Invalid lookup");
 }
 public Map<String,Object> lookupById(String kind,Long id){validateLookup(kind,kind+"_NAME");return db.one("SELECT ID FROM "+kind+" WHERE ID=:i AND DELETE_FLAG=0","i",id);}
 public void lockLookup(String kind){validateLookup(kind,kind+"_NAME");db.update("LOCK TABLE "+kind+" IN EXCLUSIVE MODE");}
 public List<Map<String,Object>> lookupByName(String kind,String column,String name){validateLookup(kind,column);return db.rows("SELECT ID FROM "+kind+" WHERE LOWER(TRIM("+column+"))=LOWER(:n) AND DELETE_FLAG=0 ORDER BY ID","n",name);}
 public long insertLookup(String kind,String column,String name){validateLookup(kind,column);return db.insert("INSERT INTO "+kind+"("+column+") VALUES(:n)","n",name);}
}
`);
edit('service/order/BillService.java',s=>s.replace('db.rows("SELECT ID,DISCOUNT_TYPE,DISCOUNT_VALUE,MAX_DISCOUNT FROM VOUCHER WHERE CODE=:c AND STATUS=1 AND STARTS_AT<=LOCALTIMESTAMP AND ENDS_AT>LOCALTIMESTAMP AND USED_COUNT<USAGE_LIMIT AND MIN_ORDER<=:s"+(consume?" FOR UPDATE":""),"c",code.trim().toUpperCase(java.util.Locale.ROOT),"s",subtotal)','queries.eligibleVoucher(consume,code.trim().toUpperCase(java.util.Locale.ROOT),subtotal)'));
edit('repository/order/OrderOperationsRepository.java',s=>s.trim().slice(0,-1)+`
 public List<Map<String,Object>> eligibleVoucher(boolean consume,String code,java.math.BigDecimal subtotal){return db.rows("SELECT ID,DISCOUNT_TYPE,DISCOUNT_VALUE,MAX_DISCOUNT FROM VOUCHER WHERE CODE=:c AND STATUS=1 AND STARTS_AT<=LOCALTIMESTAMP AND ENDS_AT>LOCALTIMESTAMP AND USED_COUNT<USAGE_LIMIT AND MIN_ORDER<=:s"+(consume?" FOR UPDATE":""),"c",code,"s",subtotal);}
}
`);
