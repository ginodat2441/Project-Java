$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
foreach($envFile in @('.vscode/oracle-local.env','.vscode/viettel-local.env')) {
 $envPath=Join-Path $projectRoot $envFile
 if(Test-Path -LiteralPath $envPath) {
  foreach($line in Get-Content -LiteralPath $envPath) {
   if($line -match '^\s*(SPRING_[A-Z_]+|SHOP_[A-Z_]+)=(.*)$') {
    [Environment]::SetEnvironmentVariable($Matches[1],$Matches[2].Trim().Trim('"').Trim("'"),'Process')
   }
  }
 }
}
$env:SPRING_DATASOURCE_URL='jdbc:oracle:thin:@//localhost:1521/FREEPDB1'
$env:SPRING_DATASOURCE_USERNAME='CLOTHING_SHOP'
$javaExe=Join-Path $env:USERPROFILE 'Downloads/sqldeveloper-26.2.0.186.2220-x64/sqldeveloper/jdk/jre/bin/java.exe'
$jarFile=Join-Path $projectRoot 'backend_java/target/clothing-shop-0.0.1-SNAPSHOT.jar'
if(Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue){throw 'Port 8080 is already in use'}
$server=Start-Process -FilePath $javaExe -ArgumentList @('-jar',('"'+$jarFile+'"')) -WorkingDirectory (Join-Path $projectRoot 'backend_java') -WindowStyle Hidden -RedirectStandardOutput (Join-Path $projectRoot '.local/server.log') -RedirectStandardError (Join-Path $projectRoot '.local/server-error.log') -PassThru
$server.Id | Set-Content -LiteralPath (Join-Path $projectRoot '.local/server.pid')
Write-Output "Started PID $($server.Id)"
