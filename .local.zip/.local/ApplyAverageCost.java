import java.sql.*;
public class ApplyAverageCost {
 public static void main(String[] args)throws Exception{
 try(var c=DriverManager.getConnection(System.getenv("SPRING_DATASOURCE_URL"),System.getenv("SPRING_DATASOURCE_USERNAME"),System.getenv("SPRING_DATASOURCE_PASSWORD"));var s=c.createStatement()){
 try(var rs=s.executeQuery("SELECT COUNT(*) FROM SHOP_MIGRATION WHERE VERSION='V006'")){rs.next();if(rs.getInt(1)>0){System.out.println("V006 already applied");return;}}
 for(String[] column:new String[][]{{"PRODUCT","AVERAGE_COST"},{"BILL_DETAIL","COST_UNIT"},{"INVENTORY_DOCUMENT_LINE","COST_UNIT"}}){
 boolean exists;try(var rs=s.executeQuery("SELECT COUNT(*) FROM USER_TAB_COLUMNS WHERE TABLE_NAME='"+column[0]+"' AND COLUMN_NAME='"+column[1]+"'")){rs.next();exists=rs.getInt(1)>0;}
 if(!exists)s.execute("ALTER TABLE "+column[0]+" ADD ("+column[1]+" NUMBER(24,8))");
 }
 s.executeUpdate("INSERT INTO SHOP_MIGRATION(VERSION) VALUES('V006')");System.out.println("V006 applied; historical unknown costs preserved");
 }
 }
}