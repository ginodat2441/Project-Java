const fs=require('fs'),path=require('path');
const base='backend_java/src/main/java/com/example/clothingshop/';
const write=(p,s)=>{fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,s)};
for(const [feature,name,methods] of [
 ['report','Report',[
 ['Map<String,Object>','report','String period,int year,Integer month,Integer quarter,LocalDate from,LocalDate to,Long productId,String q,int page','period,year,month,quarter,from,to,productId,q,page'],
 ['List<Map<String,Object>>','topProducts','int year,int limit,int minSold','year,limit,minSold']]],
 ['inventory','InventoryReport', [['Map<String,Object>','report','LocalDate from,LocalDate to,String q,int page','from,to,q,page']]],
 ['product','ProductMetrics',[
 ['Map<String,Object>','stock','String q,Long productId,int threshold,int page,java.math.BigDecimal minValue,java.math.BigDecimal maxValue','q,productId,threshold,page,minValue,maxValue'],
 ['Map<String,Object>','stock','String q,Long productId,int threshold,int page,java.math.BigDecimal minValue,java.math.BigDecimal maxValue,String stockState','q,productId,threshold,page,minValue,maxValue,stockState'],
 ['Map<String,Object>','list','String q,Long category,Integer status,int page,LocalDate from,LocalDate to','q,category,status,page,from,to']]]]){
 const p=base+`service/${feature}/${name}Service.java`;let src=fs.readFileSync(p,'utf8');
 src=src.replace(`package com.example.clothingshop.service.${feature};`,`package com.example.clothingshop.repository.${feature};`).replace('import org.springframework.stereotype.Service;','import org.springframework.stereotype.Repository;').replace('@Service','@Repository').replaceAll(name+'Service',name+'Repository');
 if(name==='ProductMetrics')src=src.replace('import com.example.clothingshop.service.report.ReportService;','import com.example.clothingshop.repository.report.ReportRepository;').replaceAll('ReportService.EVENTS','ReportRepository.EVENTS');
 write(base+`repository/${feature}/${name}Repository.java`,src);
 write(p,`package com.example.clothingshop.service.${feature};
import com.example.clothingshop.repository.${feature}.${name}Repository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.*;
/** Application boundary for ${feature} read models. SQL projections live in the repository. */
@Service
public class ${name}Service {
 private final ${name}Repository repository;
 public ${name}Service(${name}Repository repository){this.repository=repository;}
 ${name==='Report'?'public static final String EVENTS=ReportRepository.EVENTS;':''}
 ${methods.map(([ret,n,args,call])=>`public ${ret} ${n}(${args}){return repository.${n}(${call});}`).join('\n')}
}
`);
}
