import java.sql.*;
public class InspectCosts {
 public static void main(String[] args)throws Exception{
 try(var c=DriverManager.getConnection(System.getenv("SPRING_DATASOURCE_URL"),System.getenv("SPRING_DATASOURCE_USERNAME"),System.getenv("SPRING_DATASOURCE_PASSWORD"));var s=c.createStatement()){
 for(String sql:new String[]{"SELECT p.ID,p.PRODUCT_CODE,p.AVERAGE_COST,SUM(d.QUANTITY) Q FROM PRODUCT p JOIN PRODUCT_DETAIL d ON d.PRODUCT_ID=p.ID WHERE p.DELETE_FLAG=0 AND d.DELETE_FLAG=0 GROUP BY p.ID,p.PRODUCT_CODE,p.AVERAGE_COST ORDER BY p.ID","SELECT h.DOC_CODE,h.DOC_TYPE,h.STATUS,l.PRODUCT_DETAIL_ID,l.QUANTITY,l.BEFORE_QUANTITY,l.AFTER_QUANTITY,l.UNIT_COST,l.COST_UNIT FROM INVENTORY_DOCUMENT h JOIN INVENTORY_DOCUMENT_LINE l ON l.DOCUMENT_ID=h.ID ORDER BY h.ID"}){try(var r=s.executeQuery(sql)){var m=r.getMetaData();while(r.next()){for(int i=1;i<=m.getColumnCount();i++)System.out.print(m.getColumnLabel(i)+"="+r.getString(i)+" ");System.out.println();}}}
 }
 }
}