import java.sql.*;
import java.nio.file.*;
public class ApplyReceiptCost {
 public static void main(String[] args)throws Exception{
 try(var c=DriverManager.getConnection(System.getenv("SPRING_DATASOURCE_URL"),System.getenv("SPRING_DATASOURCE_USERNAME"),System.getenv("SPRING_DATASOURCE_PASSWORD"));var s=c.createStatement()){
 boolean applied;try(var rs=s.executeQuery("SELECT COUNT(*) FROM SHOP_MIGRATION WHERE VERSION='V005'")){rs.next();applied=rs.getInt(1)>0;}
 if(applied){System.out.println("V005 already applied");return;}
 boolean column;try(var rs=s.executeQuery("SELECT COUNT(*) FROM USER_TAB_COLUMNS WHERE TABLE_NAME='INVENTORY_DOCUMENT_LINE' AND COLUMN_NAME='UNIT_COST'")){rs.next();column=rs.getInt(1)>0;}
 if(!column)s.execute("ALTER TABLE INVENTORY_DOCUMENT_LINE ADD (UNIT_COST NUMBER(14,2))");
 boolean constraint;try(var rs=s.executeQuery("SELECT COUNT(*) FROM USER_CONSTRAINTS WHERE CONSTRAINT_NAME='CK_INV_UNIT_COST'")){rs.next();constraint=rs.getInt(1)>0;}
 if(!constraint)s.execute("ALTER TABLE INVENTORY_DOCUMENT_LINE ADD CONSTRAINT CK_INV_UNIT_COST CHECK (UNIT_COST >= 0)");
 s.executeUpdate("INSERT INTO SHOP_MIGRATION(VERSION) VALUES('V005')");System.out.println("V005 applied; existing purchase costs remain unknown");
 }
 }
}