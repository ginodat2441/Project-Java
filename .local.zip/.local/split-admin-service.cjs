const fs=require('fs'),path=require('path'),{mask}=require('./java-parse.cjs'),base='backend_java/src/main/java/com/example/clothingshop/';
const p=base+'service/admin/AdminService.java',src=fs.readFileSync(p,'utf8'),masked=mask(src),begin=masked.indexOf('{',masked.indexOf('public class '));let depth=1,start=begin+1,members=[];
for(let i=start;i<masked.length;i++){if(masked[i]==='{')depth++;if(masked[i]==='}'){depth--;if(depth===0)break;if(depth===1){members.push(src.slice(start,i+1).trim());start=i+1;}}if(masked[i]===';'&&depth===1){start=i+1;}}
const group={actor:['auth','AdminActorService'],color:['product','ColorService'],category:['product','CategoryService'],manager:['account','ManagerService'],access:['account','ManagerService'],customer:['account','CustomerService'],product:['product','ProductCommandService'],nextProductCode:['product','ProductCommandService'],nextSku:['product','ProductCommandService'],lookup:['product','ProductCommandService'],movement:['inventory','InventoryMovementService'],stock:['inventory','InventoryMovementService'],voucher:['promotion','VoucherService']};
const imports=src.slice(src.indexOf('import '),src.indexOf('@Service')),groups=new Map(),delegates=[];
for(const member of members){const m=mask(member).match(/\b(public|private)\s+([\w<>, ?\[\].]+?)\s+(\w+)\s*\(([^)]*)\)/s);if(!m||!group[m[3]])continue;const [,access,ret,name,params]=m,[feature,clazz]=group[name];if(!groups.has(clazz))groups.set(clazz,{feature,members:[]});groups.get(clazz).members.push(member);
 if(access==='public'){const args=params.split(',').map(p=>p.trim().match(/\w+$/)?.[0]).join(',');delegates.push(`public ${ret} ${name}(${params}){${ret==='void'?'':'return '}${clazz[0].toLowerCase()+clazz.slice(1)}.${name}(${args});}`);}}
const fields=[],params=[],assignments=[],facadeImports=[];
for(const [clazz,{feature,members}]of groups){const variable=clazz[0].toLowerCase()+clazz.slice(1);fields.push(`private final ${clazz} ${variable};`);params.push(`${clazz} ${variable}`);assignments.push(`this.${variable}=${variable};`);facadeImports.push(`import com.example.clothingshop.service.${feature}.${clazz};`);
 const dest=base+`service/${feature}/${clazz}.java`;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,`package com.example.clothingshop.service.${feature};\n${imports}\n@Service\npublic class ${clazz}{
 private final AdminRepository db;
 private final AdminOperationsRepository queries;
 private final PasswordEncoder encoder;
 public ${clazz}(AdminRepository db,AdminOperationsRepository queries,PasswordEncoder encoder){this.db=db;this.queries=queries;this.encoder=encoder;}
 ${members.join('\n\n')}
}\n`);}
fs.writeFileSync(p,`package com.example.clothingshop.service.admin;\n${imports}\n${facadeImports.join('\n')}
/** Compatibility facade; business rules are implemented in feature services. */
@Service
public class AdminService {
${fields.join('\n')}
public AdminService(${params.join(',')}){${assignments.join('\n')}}
${delegates.join('\n')}
}\n`);
