const fs=require('fs'),base='backend_java/src/main/java/com/example/clothingshop/';
const write=(p,s)=>{const path=require('path');fs.mkdirSync(path.dirname(base+p),{recursive:true});fs.writeFileSync(base+p,s)};
let p='controller/report/StatsController.java',s=fs.readFileSync(base+p,'utf8');
const start=s.indexOf('    String q ='),end=s.indexOf('    return ApiResponse.ok(sql.maps(q, Map.of("t", threshold)));',start);
let query=s.slice(start,end).replace('String q =','String q =');
s=s.slice(0,start)+'    return ApiResponse.ok(reports.lowStock(threshold));'+s.slice(end+'    return ApiResponse.ok(sql.maps(q, Map.of("t", threshold)));'.length);
s=s.replace('import com.example.clothingshop.common.SqlHelper;\n','').replace('  private final SqlHelper sql;\n','').replace('      SqlHelper sql, com.example.clothingshop.service.report.ReportService reports)','      com.example.clothingshop.service.report.ReportService reports)').replace('    this.sql = sql;\n','');write(p,s);
p='repository/report/ReportRepository.java';s=fs.readFileSync(base+p,'utf8').trim();write(p,s.slice(0,-1)+`public List<Map<String,Object>> lowStock(int threshold){\n${query}\nreturn db.rows(q,"t",threshold);\n}\n}\n`);
p='service/report/ReportService.java';s=fs.readFileSync(base+p,'utf8').trim();write(p,s.slice(0,-1)+'public List<Map<String,Object>> lowStock(int threshold){return repository.lowStock(threshold);}\n}\n');
write('dto/dev/SqlRequest.java','package com.example.clothingshop.dto.dev;\npublic record SqlRequest(String sql) {}\n');
write('repository/dev/SqlConsoleRepository.java',`package com.example.clothingshop.repository.dev;
import com.example.clothingshop.common.SqlHelper;
import org.springframework.stereotype.Repository;
import java.util.*;
@Repository
public class SqlConsoleRepository {
 private final SqlHelper sql;
 public SqlConsoleRepository(SqlHelper sql){this.sql=sql;}
 public List<Map<String,Object>> execute(String statement){return sql.maps(statement,Map.of());}
}
`);
p='controller/dev/SqlConsoleController.java';s=fs.readFileSync(base+p,'utf8');const body=s.slice(s.indexOf('    String s ='),s.indexOf('    return ApiResponse.ok(sql.maps(s, Map.of()));'));
write('service/dev/SqlConsoleService.java',`package com.example.clothingshop.service.dev;
import com.example.clothingshop.dto.dev.SqlRequest;
import com.example.clothingshop.common.BusinessException;
import com.example.clothingshop.repository.dev.SqlConsoleRepository;
import org.springframework.stereotype.Service;
import java.util.*;
@Service
public class SqlConsoleService {
 private final SqlConsoleRepository repository;
 public SqlConsoleService(SqlConsoleRepository repository){this.repository=repository;}
 public List<Map<String,Object>> execute(SqlRequest req){${body}return repository.execute(s);}
}
`);
s=s.replace('import com.example.clothingshop.common.SqlHelper;','import com.example.clothingshop.service.dev.SqlConsoleService;\nimport com.example.clothingshop.dto.dev.SqlRequest;').replaceAll('private final SqlHelper sql','private final SqlConsoleService service').replace('SqlConsoleController(SqlHelper sql)','SqlConsoleController(SqlConsoleService service)').replace('this.sql = sql','this.service = service').replace('  public record SqlRequest(String sql) {}','').replace(body,'').replace('ApiResponse.ok(sql.maps(s, Map.of()))','ApiResponse.ok(service.execute(req))');write(p,s);
